package pl.heinzelman.CNN;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import pl.heinzelman.CNN.net.Teacher;

@SpringBootApplication
public class CnnApplication {

	public static void main(String[] args) {

		Teacher.prepare( 8 );
		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

		Teacher.train( 5000 );
		Teacher.test( 1000 );

	}

}
